

<hr>
<footer id="colophon" class="site-footer">
		<div class="site-info">
			<div class="container footer-content">
				<div class="row footer-row">
					<div class="col1 col-xs-12 col-md-6 col-lg-3">
						<h5>Gegevens:</h5>
						<?php echo userinfo_global($html) ?>
					</div>
					<div class="col2 col-xs-12 col-md-6 col-lg-3">
						<h5>Legal</h5>
						<p><a href="#">Disclaimer</a></p>
						<p><a href="#">Voorwaarden</a></p>
						<p><a href="#">Privacybeleid</a></p>
					</div>
					<div class="col3 col-xs-12 col-md-6 col-lg-3">
						<h5>Volg ons</h5>
						<a href="#"><i class="fab fa-facebook-f"></i></a>
						<a href="#"><i class="fab fa-instagram"></i></a>
						<a href="#"><i class="fab fa-twitter"></i></a>
						<a href="#"><i class="fab fa-linkedin-in"></i></a>
					</div>
					<div class="col4 col-xs-12 col-md-6 col-lg-3">
						<a href="#">
							<img src="http://192.168.64.2/Unyt%20thema/wp-content/themes/unyt-thema/Unyt_logo_FC-Klein.jpeg" alt="">
						</a>
					</div>
				</div>
				<div class="copyright">
					<p>Copyright © 2020 Unyt Marketing Bureau</p>
				</div>

			</div>

		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
